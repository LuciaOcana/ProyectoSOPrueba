﻿namespace _1._1Lucia
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nombre = new System.Windows.Forms.TextBox();
            this.PartidasGanadas = new System.Windows.Forms.RadioButton();
            this.ID = new System.Windows.Forms.RadioButton();
            this.TablonesJugados = new System.Windows.Forms.RadioButton();
            this.EnviarButton = new System.Windows.Forms.Button();
            this.NombreLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Nombre
            // 
            this.Nombre.Location = new System.Drawing.Point(444, 90);
            this.Nombre.Name = "Nombre";
            this.Nombre.Size = new System.Drawing.Size(115, 26);
            this.Nombre.TabIndex = 0;
            // 
            // PartidasGanadas
            // 
            this.PartidasGanadas.AutoSize = true;
            this.PartidasGanadas.Location = new System.Drawing.Point(324, 209);
            this.PartidasGanadas.Name = "PartidasGanadas";
            this.PartidasGanadas.Size = new System.Drawing.Size(131, 23);
            this.PartidasGanadas.TabIndex = 1;
            this.PartidasGanadas.TabStop = true;
            this.PartidasGanadas.Text = "Partidas ganadas";
            this.PartidasGanadas.UseVisualStyleBackColor = true;
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(311, 271);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(41, 23);
            this.ID.TabIndex = 3;
            this.ID.TabStop = true;
            this.ID.Text = "ID";
            this.ID.UseVisualStyleBackColor = true;
            // 
            // TablonesJugados
            // 
            this.TablonesJugados.AutoSize = true;
            this.TablonesJugados.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.TablonesJugados.Location = new System.Drawing.Point(324, 238);
            this.TablonesJugados.Name = "TablonesJugados";
            this.TablonesJugados.Size = new System.Drawing.Size(131, 23);
            this.TablonesJugados.TabIndex = 4;
            this.TablonesJugados.TabStop = true;
            this.TablonesJugados.Text = "Tablones jugados";
            this.TablonesJugados.UseVisualStyleBackColor = true;
            // 
            // EnviarButton
            // 
            this.EnviarButton.Location = new System.Drawing.Point(368, 345);
            this.EnviarButton.Name = "EnviarButton";
            this.EnviarButton.Size = new System.Drawing.Size(86, 26);
            this.EnviarButton.TabIndex = 5;
            this.EnviarButton.Text = "Enviar";
            this.EnviarButton.UseVisualStyleBackColor = true;
            // 
            // NombreLabel
            // 
            this.NombreLabel.AutoSize = true;
            this.NombreLabel.Location = new System.Drawing.Point(283, 96);
            this.NombreLabel.Name = "NombreLabel";
            this.NombreLabel.Size = new System.Drawing.Size(59, 19);
            this.NombreLabel.TabIndex = 6;
            this.NombreLabel.Text = "Nombre";
            this.NombreLabel.Click += new System.EventHandler(this.NombreLabel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.NombreLabel);
            this.Controls.Add(this.EnviarButton);
            this.Controls.Add(this.TablonesJugados);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.PartidasGanadas);
            this.Controls.Add(this.Nombre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Nombre;
        private RadioButton PartidasGanadas;
        private RadioButton ID;
        private RadioButton TablonesJugados;
        private Button EnviarButton;
        private Label NombreLabel;
    }
}