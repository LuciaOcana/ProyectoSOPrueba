using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace _1._1Lucia
{
    public partial class Form1 : Form
    {
        Socket server;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Establecemos la connexi�n
            IPAddress direc = IPAddress.Parse("192.168.56.101");
            IPEndPoint ipep = new IPEndPoint(direc, 9070);

            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectar el socket
                //Si al intentar conectarse, hemos realizado correctamente la conexi�n, pondremos el fondo de la pantalla del Form en verde y mostraremos un mensaje
                //que indique que nos hemos conectado correctamente
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");

                //Si hemos seleccionado el boton de PArtidas ganadas
                if (PartidasGanadas.Checked)
                {
                    //A la variable "mensaje" le asignamos un mensaje que contenga el identificador de la acci�n que hemos seleccionado (la indicaremos con el numero
                    //de antes de la "/") y el nombre que hemos introducido en la caja del Form llamada "Nombre".
                    string mensaje = "1/" + Nombre.Text;
                    //Enviamos el mensaje al servidor
                    //enviaremos el mensaje como un vector de bytes
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    //Recibiremos la respuesta del servidor
                    byte[] msg2 = new byte[80];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0]; //El "split" lo que hara sera partir el mensaje por el final del string y se quedara solo
                    //con el primer trozo (esto se hace para no recibir y trabajar con la basura que se acumula durante el proceso de enviar y recibir la informacion
                    //del servidor.
                    MessageBox.Show(Nombre.Text + "ha ganado:" + mensaje + "partidas");
                }
                if (TablonesJugados.Checked)
                {

                    //A la variable "mensaje" le asignamos un mensaje que contenga el identificador de la acci�n que hemos seleccionado (la indicaremos con el numero
                    //de antes de la "/") y el nombre que hemos introducido en la caja del Form llamada "Nombre".
                    string mensaje = "2/" + Nombre.Text;
                    //Enviamos el mensaje al servidor
                    //enviaremos el mensaje como un vector de bytes
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    //Recibiremos la respuesta del servidor
                    byte[] msg2 = new byte[80];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0]; //El "split" lo que hara sera partir el mensaje por el final del string y se quedara solo
                    //con el primer trozo (esto se hace para no recibir y trabajar con la basura que se acumula durante el proceso de enviar y recibir la informacion
                    //del servidor.
                    MessageBox.Show(Nombre.Text + "ha jugado en:" + mensaje + "tablones");
                }
                if (ID.Checked) //En el caso de que selecciones ver la ID del jugador
                {
                    //A la variable "mensaje" le asignamos un mensaje que contenga el identificador de la acci�n que hemos seleccionado (la indicaremos con el numero
                    //de antes de la "/") y el nombre que hemos introducido en la caja del Form llamada "Nombre".
                    string mensaje = "3/" + Nombre.Text;
                    //Enviamos el mensaje al servidor
                    //enviaremos el mensaje como un vector de bytes
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                    //Recibiremos la respuesta del servidor
                    byte[] msg2 = new byte[80];
                    server.Receive(msg2);
                    mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0]; //El "split" lo que hara sera partir el mensaje por el final del string y se quedara solo
                    //con el primer trozo (esto se hace para no recibir y trabajar con la basura que se acumula durante el proceso de enviar y recibir la informacion
                    //del servidor.
                    MessageBox.Show(Nombre.Text + "tiene la ID:" + mensaje);
                }
                //Se ha acabado el servicio por tanto cambio la pantalla a blanca y me desconecto.
                this.BackColor = Color.White;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
            }
            catch (SocketException ex)
            {
                //Si hay una excepcion imprimimos en pantalla el error y salimos del programa (return)
                MessageBox.Show("No me he podido conectar al servidor");
                return;
            }

        }

       private void NombreLabel_Click(object sender, EventArgs e)
        {

        }
    }
}